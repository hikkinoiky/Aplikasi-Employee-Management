export interface Student {
    _id: string;
    name: string;
    age: number;
}
