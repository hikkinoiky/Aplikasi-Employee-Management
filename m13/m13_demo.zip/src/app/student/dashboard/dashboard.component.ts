import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/student';
import { StudentService } from 'src/app/student.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  students: Student[] = [];


  constructor(private studentService: StudentService) { }

  ngOnInit(): void {
    this.studentService.getAll().subscribe(students => {
      this.students = students;
    }) 
  }

  hapus(id: string) {
    // tambahkan confirmation alert modal
    this.studentService.delete(id).subscribe(() => {
      window.location.reload()
    });
  }

}
